# Execute FIR code in user BRAM

## Simulation for FIR
```sh
cd ~/caravel-soc_fpga-lab/lab-exmem-fir/testbench/counter_la_fir
source run_clean
source run_sim
```
